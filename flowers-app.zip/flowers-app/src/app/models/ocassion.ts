export interface IOcassion {
  id: string, name: string
}